//Initialisation de la carte

var map = L.map('map').setView([46.5,3], 6);

L.tileLayer('https://wxs.ign.fr/{apikey}/geoportail/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0&STYLE={style}&TILEMATRIXSET=PM&FORMAT={format}&LAYER=GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}', {
	attribution: '<a target="_blank" href="https://www.geoportail.gouv.fr/">Geoportail France</a>',
	bounds: [[-75, -180], [81, 180]],
	minZoom: 2,
	maxZoom: 18,
	apikey: 'choisirgeoportail',
	format: 'image/png',
	style: 'normal'
}).addTo(map);


//Ajout des frontières départementales

var dep_layer = L.layerGroup(); //Création du layerGroup qui contiendra un à un les frontières des départements visités
                                //Le layerGroup est utilisé pour contrer l'asynchronisation de l'algorithme.

function fetchJSON(url, code_dep) { //Appel du GEOJSON stocké dans le dossier, contenant les frontières de chaque département métropolitain
  return fetch(url)
  .then(result => result.json())
  .then(r => {
    for (var i = 0; i <= 96; i++) {
      if (r['features'][i]['properties']['code'] == code_dep) { //Grâce au 'for... if...', on trouve les frontières correspondant au département souhaité.
        L.geoJSON(r['features'][i]).addTo(dep_layer); //Ajout des frontières dans le layerGroup
        dep_layer.addTo(map); //Ajout du layerGroup sur la carte
      }
    }
  });
  }


//Attribution des éléments de l'interface du jeu

var temps = document.getElementById('temps');
var code = document.getElementById('code');
var form_x = document.getElementById('form_x');
var indice = document.getElementById('indice');
var position = document.getElementById('position');
var progression = document.getElementById('progression');
var inventaire = document.getElementById('inventaire');


//Initialisation des données utilisateur et des paramètres de jeu

var liste = [0]; //Initialisation de la liste. Le premier élément correspond au parchemin du centre de la France.
const nb_dest = parseInt(sessionStorage.getItem('nb_dest')); //Nombre de DestiNations rentré dans la page d'accueil
const pseudo = sessionStorage.getItem('pseudo'); //Pseudo du joueur
console.log(pseudo);
const nb_total = 96; //Nombre de destinations dans la base de données

var nb_iter = 0;
var code_test = '';
var score_test = 0;
var chrono_test = 0


//Explication des consignes, avant d'appuyer sur le premier parchemin 

position.innerHTML = '<li><p>∙ Ici seront affichés les indices pour chaque DestiNation que tu dois trouver</p></li><li><p>∙ Si tu ne l`as pas trouvée au bout de 45s, le département dans lequel elle se situe s`ajoutera</p></li><li><p>∙ Au bout d`1min30, les frontières de ce département apparaîtront</p></li><li><p>∙ Au bout de 2min15, une description de la DestiNation te sera donnée</p></li>';
indice.innerHTML = '<li><p>∙ Là, il y aura la place pour toutes les DestiNations que tu as trouvées</p></li><li><p>∙ Pour commencer le jeu, clique sur le parchemin au centre de la France</p></li><li><p>∙ Bon jeu à toi, ' + pseudo +' !</p></li>';


//Détermination de l'id de chaque destination

function randomId(liste) { //Fonction qui ajoute à une liste un nombre aléatoire qui n'est pas présent dans celle-ci 
  var id = Math.floor(Math.random() * nb_total + 1);
  while (liste.includes(id)) {
    id = Math.floor(Math.random() * nb_total + 1);
  }
  liste.push(id);
  return(liste);
}

for (var i = 0; i < nb_dest; i++) { //La liste aura comme taille le nombre de DestiNations souhaité + 1, le parchemin de départ.
  liste = randomId(liste);
}


//Lancement du jeu

tableau_destination(0);


//Fonction du jeu

function tableau_destination(id){

  nb_iter++; //On incrémente à chaque passage pour déterminer à quelle étape nous sommes.


  //Détermination de l'objet à ajouter sur la carte en fonction du nombre d'itérations faites de la fonction.

  if (nb_iter == nb_dest - 1) {
    var num = 2;
  }
  else if (nb_iter == nb_dest) {
    var num = 3;
  }
  else if (nb_iter == nb_dest + 1) {
    var num = 4;
  }
  else {
    var num = 1;
  }


  //Requête à la base de données
  //Tout le programme se fait dans cette fonction pour palier à l'asynchronisation.

  var data = "id="+(id*10+num); //Encodage de l'id de la destination et de l'objet à ajouter à la carte
  fetch('../php/bdd_destination.php', {
      method: 'post',
      body: data,
      headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      })
      .then(result => result.json())
      .then(r => {

          //Le JSON renvoyé est la jointure entre les propriétés de la destination (cf. table 'destinations')
          // et les propriétés de l'objet à ajouter sur la carte (cf. table 'objets') 

          if(nb_iter == 1) { //Si c'est la première fois que la fonction est sollicitée, le premier élément sera un parchemin visible
          // n'importe le zoom. Il se situe au centre de la France et permet de lancer le jeu en faisant comprendre 
          //à l'utilisateur comment jouer.
            var objet = L.marker([r[0]['lat'], r[0]['lon']], {icon: L.icon({ //Création de l'icone de l'objet et ajout à la carte
              iconUrl: '../images/'+r[0]['o_png'],
              iconSize:     [r[0]['o_longueur'], r[0]['o_hauteur']],
              iconAnchor:   [r[0]['o_longueur']/2, r[0]['o_hauteur']/2]
            })}).addTo(map);
            objet.on('click', function(e){ //Quand le parchemin est cliqué, on l'enlève et on lance la fonction pour le prochain objet.
              indice.innerHTML = '';
              objet.remove(); //Retrait du premier parchemin


              //Chronomètre

              const temps_initial = Date.now(); //Détermination de la date de début de partie, quand le joueur clique sur le premier parchemin
              setInterval(function() { //Départ du chronomètre lorsque le parchemin de départ est utilisé
                chrono_test = Date.now() - temps_initial;
                if (chrono_test > 60000) { //Affichage du chronomètre
                  if (chrono_test > 3600000) {
                    temps.innerText = 'Temps écoulé : ' + Math.floor(chrono_test/3600000) + 'h ' + Math.floor((chrono_test%3600000)/60000) + 'min ' + Math.floor((chrono_test%60000)/1000) + 's';
                  }
                  else {
                    temps.innerText = 'Temps écoulé : ' + Math.floor(chrono_test/60000) + 'min ' + Math.floor((chrono_test%60000)/1000) + 's';
                  }
                }
                else {
                  temps.innerText = 'Temps écoulé : ' + Math.floor(chrono_test/1000) + 's';
                }
              },1000);


              progression.innerText = 'Progression : ' + (nb_iter-1) + '/' + nb_dest;  //Intitialisation de la progression
              tableau_destination(liste[nb_iter]); //Lancement de la deuxième étape
          })
        }


          if (nb_iter != 1) { //Si ce n'est pas l'étape du premier parchemin.
            var date_debut = Date.now(); //Temps de départ de l'étape utile pour le score
            var clicked = false; //La variable 'clicked' permet de savoir si l'objet a été cliqué, pour sortir de la fonction 'zoom'.
            position.innerHTML = '<li><p>∙ ' + r[0]['nom'] + '</p></li>' //Initialisation de la colonne de gauche avec le nom de la DestiNation.      
            
            
            //Fonction qui modifie les éléments des colonnes d'indices selon le temps passé sur l'étape
            
            var i = 0; //Permet seulement le bon fonctionnement de la fonction
            setInterval(function() { 
              if (!clicked) { 

                if (i == 0) {
                  position.innerHTML += '<li><p>∙ ' + r[0]['nom_dep'] + '</p></li>'; //Ajout du nom du département dans la colonne de gauche après 45s
                }
                else if (i == 1) {
                  fetchJSON('../contour-des-departements.geojson', r[0]['code_dep']); //Ajout des frontières du département souhaité à 90s
                }
                else if (i == 2) {
                  position.innerHTML += '<li><p>∙ ' + r[0]['indice'] + '</p></li>'; //Ajout de l'indice dans la colonne de gauche après 135s
                }
              i++;
              }
            },45000); //Temps à partir duquel les indices apparaissent, soit chaque 45s


            code_test += r[0]['code_dep']; //Ajout du département au code secret.

            var objet = L.marker([r[0]['lat'], r[0]['lon']], {icon: L.icon({ //Création de l'icone de l'objet.
              iconUrl: '../images/'+r[0]['o_png'],
              iconSize:     [r[0]['o_longueur'], r[0]['o_hauteur']],
              iconAnchor:   [r[0]['o_longueur']/2, r[0]['o_hauteur']/2]
            })});  


            //Évènement qui détermine le niveau de zoom minimum de l'objet

            map.on('zoom', function(e) { //Si ce n'est pas la première fois que la fonction est sollicitée, l'objet sera visible en
              // fonction du zoom. On l'ajoute à la carte si et seulement si le zoom est assez fort.
              if (!clicked){
                var zoomlevel = map.getZoom();
                if (zoomlevel < 16) {
                  objet.remove();
                }
                if (zoomlevel >= 16) {
                  objet.addTo(map);
                }
              }
            });


            //Évènement qui permet d'avancer dans le jeu lorsque l'objet est cliqué

            objet.on('click', function(e){ //Quand l'objet est cliqué, on l'enlève et on lance la fonction pour le prochain objet,
              // mis à part si c'est le dernier.
              clicked = true;
              indice.innerHTML += '<li><p>∙ ' + r[0]['nom'] + '</p></li>'; //Ajout de la destination dans la colonne de droite
              progression.innerText = 'Progression : ' + (nb_iter-1) + '/' + nb_dest; //Mise à jour de la progression
              dep_layer.clearLayers(); //Mise à zéro du layerGroup des frontières départementales
              var delta_t = Date.now() - date_debut; //Détermination du temps passé sur l'étape
              score_test += r[0]['difficulte'] / Math.sqrt(delta_t); //Ajout du score partiel au score total

              if (num == 1) { //Si l'objet est un parchemin
                objet.remove(); //Retrait de l'objet
                tableau_destination(liste[nb_iter]); //Lancement de la prochaine étape
                map.setView([46.5,3], 6); //Réinitialisation du point de vue de la carte
              }
              if (num == 2) { //Si l'objet est la clé
                inventaire.innerHTML = '<li><a href="#">Clé</a></li>'; //Ajout de la clé à l'inventaire
                objet.remove(); //Retrait de l'objet
                tableau_destination(liste[nb_iter]); //Lancement de l'avant-dernière étape
                map.setView([46.5,3], 6); //Réinitialisation du point de vue de la carte
              }
              if (num == 3) { //Si l'objet est le coffre à clé
                //Pas besoin de vérifier si le joueur a la clé car il ne pourrait pas arriver ici sans l'avoir.
                inventaire.innerHTML = ''; //Retrait de la clé de l'inventaire
                objet.remove(); //Retrait de l'objet
                tableau_destination(liste[nb_iter]); //Lancement de la dernière étape
                map.setView([46.5,3], 6); //Réinitialisation du point de vue de la carte
              }
              if (num == 4) { //Si l'objet est le coffre à code
                sessionStorage.setItem('score', 1000000*score_test/nb_dest); //Mise en mémoire du score
                sessionStorage.setItem('date_coffre_clic', Date.now()); //Mise en mémoire de la date du clic sur le coffre à code
                document.getElementById("code").style.display = "block"; //Affichage du pop-up du code


                //Étude du code rentré dans le popu-up

                var bouton_mis = false; //Variable qui coorespond à la présence du bouton de sortie dans le pop-up
                code.addEventListener('input', function(e) { //Affiche le bouton de sortie si et seulement si le code rentré est le bon
                  var interieur_code = form_x.elements["code"].value;
                  if (interieur_code == code_test && !bouton_mis) {
                    bouton_mis = true;
                    form_x.innerHTML += "<p><input type='submit' name='valider' value='TERMINER' id = 'submit' onclick=`window.location.href = 'web.html'`></p>";
                  }
                })
              }
        });
        }
      }
      
      )
}

//BDD
//Changer 04, 05






