//Partie JavaScript de l'écran de fin


//Récupération des variables utiles des autres fichiers JavaScript

var score_test = parseInt(sessionStorage.getItem('score'));
var date_coffre_clic = parseInt(sessionStorage.getItem('date_coffre_clic'));
var pseudo_test = sessionStorage.getItem('pseudo');
var nb_dest = sessionStorage.getItem('nb_dest');

//Attribution des éléments de l'interface

var pseudo = document.getElementById('pseudo');
var score = document.getElementById('score');


//Calcul du score final

var delta_t = Date.now() - date_coffre_clic;
score_test += 1000000 / (3000 + Math.sqrt(delta_t));
score_test *= (1+ 2 * nb_dest / 96);
score_final = Math.floor(score_test);


//Affichage des résultats

pseudo.innerText = 'Félicitations ' + pseudo_test + ' ! Tu as terminé la partie.';
score.innerText = 'Score : ' + score_final;