//Partie JavaScript de l'écran d'accueil


//Attribution des éléments de l'interface

var form = document.getElementById('formulaire');
var bouton = form.elements['submit'];
var input_pseudo = form.elements['pseudo'];


//Évènement sur le bouton 'COMMENCER'

bouton.addEventListener('click', function(e) { //Quand le bouton est pressé, on envoie le pseudo du joueur et le nombre 
// de DestiNations au sessionStorage
    sessionStorage.setItem('nb_dest',form.elements["nb_dest"].value);   
    sessionStorage.setItem('pseudo',form.elements["pseudo"].value); 
});
