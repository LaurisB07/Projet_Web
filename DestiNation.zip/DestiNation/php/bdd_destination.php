<?php


//Partie à modifier (copier-coller depuis le Web Start Page de MAMP par exemple)

$user = 'root';
$password = '';
$db = 'bdd_destination';
$host = 'localhost';
$port = 3306;

$link = mysqli_init();
$success = mysqli_real_connect(
   $link, 
   $host, 
   $user, 
   $password, 
   $db,
   $port
);

//Fin de la partie à modifier


//Envoi d'un message d'erreur si le lien n'a pas été fait

if (!$link) {
  die('Erreur de connexion');
}


//Encodage du lien

mysqli_set_charset($link, "utf8");


//Création du rendu de la requête SQL faite dans le JavaScript

$destinations = [];

if (isset($_POST['id'])){
    $id = floor($_POST['id']/10); //Décodage des paramètres de la requête
    $num = $_POST['id']%10;
    $destination = mysqli_query($link, "SELECT * FROM destinations AS d JOIN objets AS o WHERE d.id =".$id." AND o.o_id=".$num."");
    foreach($destination as $elem){
        $destinations[] = $elem;
    }
    echo json_encode($destinations, JSON_UNESCAPED_UNICODE);
}


?>