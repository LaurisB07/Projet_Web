-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : dim. 04 déc. 2022 à 23:26
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `bdd_destination`
--

-- --------------------------------------------------------

--
-- Structure de la table `destinations`
--

DROP TABLE IF EXISTS `destinations`;
CREATE TABLE IF NOT EXISTS `destinations` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` text COLLATE utf8_bin NOT NULL,
  `lat` float NOT NULL,
  `lon` float NOT NULL,
  `nom_dep` text COLLATE utf8_bin NOT NULL,
  `indice` text COLLATE utf8_bin NOT NULL,
  `code_dep` text COLLATE utf8_bin NOT NULL,
  `difficulte` float NOT NULL DEFAULT '1',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `destinations`
--

INSERT INTO `destinations` (`id`, `nom`, `lat`, `lon`, `nom_dep`, `indice`, `code_dep`, `difficulte`) VALUES
(0, 'Départ', 46.5, 3, '', '', '', 1),
(1, 'Le Grand Colombier', 45.9004, 5.76105, 'Ain', 'Le Grand Colombier est une montagne qui domine le Bugey. Il est au Nord de Belley et du Lac du Bourget', '01', 2.5),
(3, 'Le Parc des Sources de Vichy', 46.1246, 3.4201, 'Allier', 'Vichy borde l`Allier, au centre de la France. La ville est connue pour ses sources aux propriétés thermales.', '03', 1.5),
(4, 'Les Rochers des Pénitents', 44.0322, 5.9859, 'Alpes-de-Haute-Provence', 'Les Rochers des Pénitents paraissent irréels au vu de leur forme. Elles se formèrent du temps où la Mer Méditerranée coulait encore aux Mées, entre Manosque et Sisteron.', '04', 3),
(5, 'Le Lac de Serre-Ponçon', 44.523, 6.36264, 'Hautes-Alpes', 'Le Lac de Serre-Ponçon est formé par la Durance, issu d`un torrent alpin.', '05', 1.5),
(6, 'La Promenade des Anglais', 43.695, 7.26782, 'Alpes-Maritimes', 'La Promenade des Anglais située à Nice est fameuse pour la célébration du 14 juillet.', '06', 1.5),
(7, 'Le Pont d`Arc', 44.3819, 4.41623, 'Ardèche', 'Le Pont d`Arc est une merveille géologique formée grâce aux méandres de l`Ardèche, dans ses fameuses gorges.', '07', 2.5),
(8, 'La Citadelle de Givet', 50.1348, 4.80894, 'Ardennes', 'La Citadelle surplombe la ville du même nom, situé dans l`appendice de la France en Belgique.', '08', 2),
(9, 'Le Château de Foix', 42.9656, 1.60487, 'Ariège', 'Le Château de Foix domine sa ville. Il représente l`entrée dans les Pyrénnées Ariègeoises.', '09', 2),
(10, 'Les Cheminées de Nogent-sur-Seine', 48.5142, 3.51667, 'Aube', 'Nogent-sur-Seine se trouve entre Troyes et Provins. Ses Cheminées sont connues pour être très proche de la ville.', '10', 2),
(11, 'La Cité de Carcassonne', 43.206, 2.36424, 'Aude', 'La Cité de Carcassonne est située entre Toulouse et la Mer Méditérannée. Y siégèrent les plus braves chevaliers.', '11', 1.5),
(12, 'Le Viaduc de Millau', 44.0851, 3.02166, 'Aveyron', 'Le Viaduc de Millau enjambe le Tarn, dans le Parc Naturel Régional des Grands Causses', '12', 2),
(13, 'Le Vieux Port', 43.2951, 5.37384, 'Bouches-du-Rhône', 'Le Vieux Port est le symbole de la ville de Marseille. La légende raconte qu`on y trouve seulement des scooters, des Parisiens et des rascasses.', '13', 1),
(14, 'Omaha Beach', 49.3694, -0.871154, 'Calvados', 'Omaha Beach est au Nord-Ouest de Bayeux. C`est peut-être grâce à cette plage qu`on parle Français maintenant.', '14', 2),
(15, 'Le Puy Mary', 45.1093, 2.6765, 'Cantal', 'Le Puy Mary est un des sommets du Massif Central. Il est en plein centre du Cantal, au Nord-Est d`Aurillac.', '15', 2.5),
(16, 'Le Château de Cognac', 45.6986, -0.329535, 'Charente', 'Le Château de Cognac est aussi une distillerie historique comme on peut s`en douter ! Il est placé proche de la Charente, entre Saintes et Angoulême.', '16', 1.5),
(17, 'Le Fort Boyard', 45.9997, -1.21393, 'Charente-Maritime', 'Le Fort Boyard, emblème du jeu télévisé éponyme se place entre l`île d`Aix et l`île d`Oléron.', '17', 2),
(18, 'Le Village de Sancerre', 47.3306, 2.83882, 'Cher', 'Le Village de Sancerre a été labellisé `Plus beau village de France` en 2022. Plein d`histoire, il se trouve au Nord-Est de Bourges, non loin de la Nièvre.', '18', 2.5),
(19, 'Le Haras national de Pompadour', 45.3971, 1.37816, 'Corrèze', 'Le Haras national de Pompadour est l`un des hauts lieux de l`évènementiel équestre en France, situé à l`Ouest d`Uzerches, au Nord de Brive-la-Gaillarde.', '19', 3),
(20, 'La Citadelle de Bonifacio', 41.3879, 9.16057, 'Corse-du-Sud', 'La Citadelle de Bonifacio trône sur sa ville et sur la Mer Corse et Sarde.', '2A', 1.5),
(21, 'Le Palazzu di i Guvernadori', 42.6937, 9.45104, 'Haute-Corse', 'Le Palazzu di i Guvernadori ou Palais des Gouverneurs en français fut construit lors de la domination génoise, à Bastia.', '2B', 2),
(22, 'La Source de la Seine', 47.486, 4.71696, 'Côte-d`Or', 'La Source de la Seine est le commencement du long voyage du fleuve parisien. Elle se trouve à Source-Seine, entre Dijon et Montbard.', '21', 3),
(23, 'Le Stade de Roudourou', 48.5661, -3.16442, 'Côtes-d`Armor', 'Le Stade de Roudourou voit jouer l`équipe de football de Guinguamp, dans l`Ouest costarmoricain. C`est une petite ville mais une grosse histoire avec le sport.', '22', 2),
(24, 'L`île de Vassivière', 45.8046, 1.86881, 'Creuse', 'L`île de Vassivière est située dans le Lac de la Maulde, entre la Creuse et la Haute-Vienne. Oui, il n`y a rien à voir en Creuse.', '23', 3),
(25, 'La Grotte de Lascaux', 45.0539, 1.17076, 'Dordogne', 'La Grotte de Lascaux est la référence française pour l`art préhistorique. C`est à Montignac-Lascaux, au Nord de Sarlat-la-Canéda que les peintures résident.', '24', 2),
(26, 'La République du Saugeais', 46.9925, 6.46213, 'Doubs', 'La République du Saugeais est une micronation vue sérieusement par certains et comme une blague par tous les autres. Elle regroupe 11 communes françaises et a comme capitale, Montbenoît, au Nord-Est de Pontarlier.', '25', 2.5),
(27, 'Le Château de Grignan', 44.4189, 4.90886, 'Drôme', 'Le Château de Grignan logeait autrefois la Marquise de Sévigné, au Sud-Est de Montélimar.', '26', 2),
(28, 'Les Jardins de Claude Monet', 49.075, 1.53361, 'Eure', 'Les Jardins de Claude Monet étaient sa plus intense source d`inspiration. Ils se trouvent à Giverny, à la frontière avec les Yvelines.', '27', 2.5),
(29, 'La Cathédrale Notre-Dame de Chartres', 48.4479, 1.48791, 'Eure-et-Loir', 'Le Roi Louis XIV gardait toujours un oeil sur cette Cathédrale depuis Versailles, au Nord-Est de celle-ci.', '28', 1.5),
(30, 'L`île d`Ouessant', 48.4649, -5.0851, 'Finistère', 'L`île d`Ouessant est le lieu le plus à l`Ouest de France métropolitaine. C`est la porte des Amériques !', '29', 2),
(31, 'Le Pont du Gard', 43.9475, 4.5351, 'Gard', 'Cet aqueduc romain de trois étages laisse le Gardon couler entre ses piliers. Il acheminait l`eau d`Uzès à Nîmes, en passant à Remoulins.', '30', 2),
(32, 'La Place du Capitole', 43.6044, 1.44341, 'Haute-Garonne', 'La Place du Capitole est en plein centre de la ville rose.', '31', 1),
(33, 'La Cathédrale Sainte-Marie d`Auch', 43.6463, 0.585988, 'Gers', 'La Cathédrale Sainte-Marie d`Auch est, comme son nom l`indique, à Auch, à l`Ouest de Toulouse.', '32', 1.5),
(34, 'Le Phare du Cap Ferret', 44.6458, -1.24875, 'Gironde', 'Le Phare du Cap Ferret permet même au moins bon des marins de trouver une entrée dans la Baie d`Arcachon.', '33', 2),
(35, 'Le Canal Royal de Sète', 43.3994, 3.69727, 'Hérault', 'Le Canal Royal de Sète a vu les plus grands jouteurs occitans tomber à l`eau. Entre Montpellier et Béziers, sur la côte.', '34', 1.5),
(36, 'Les Remparts de Saint-Malo', 48.6498, -2.02851, 'Ille-et-Vilaine', 'Les Remparts de Saint-Malo protégeaint la cité des futiles attaques anglaises, au Sud de Jersey.', '35', 1),
(37, 'Le Château Raoul', 46.8126, 1.68584, 'Indre', 'Le Château Raoul est l`origine étymologique de la ville de Châteauroux, en plein centre de l`Indre.', '36', 2),
(38, 'Le Château de Chenonceau', 47.3249, 1.07028, 'Indre-et-Loire', 'Le Château de Chenonceau est fulgurant : il est posé sur l`eau du Cher. À l`Est de Tours, au Sud-Est d`Amboise.', '37', 1.5),
(39, 'Le Mont Aiguille', 44.8418, 5.55321, 'Isère', 'Le Mont Aiguille est un massif rocheux très surprenant au vu de sa forme. Il est situé dans le Vercors, entre Die et La Mure.', '38', 2.5),
(40, 'Les Cascades du Hérisson', 46.6153, 5.86648, 'Jura', 'Les Cascades du Hérisson sont un enchaînement surprenant de chutes d`eau, à l`Est de Lons-le-Saunier et au Sud de Champagnole.', '39', 3.5),
(41, 'Les Arènes de Dax', 43.7129, -1.05005, 'Landes', 'Bien moins connues que celles d`Arles ou de Nîmes, les Arènes de Dax n`en restent pas moins attrayantes. Entre Mont-de-Marsan et Bayonne.', '40', 1.5),
(42, 'Le Château de Chambord', 47.6162, 1.51698, 'Loir-et-Cher', 'Le Château de Chambord est sans doute le château le plus mythique de la Loire, entre Blois et Orléans.', '41', 1.5),
(43, 'Le Crêt de la Perdrix', 45.3825, 4.57279, 'Loire', 'Le Crêt de la Perdrix est en fait le point culminant des Monts du Pilat, dans l`Est de la Loire. Il offre une vue imprenable sur la Vallée du Rhône.', '42', 3),
(44, 'Le Mont Mézenc', 44.9142, 4.18992, 'Haute-Loire', 'Le Mont Mézenc est le point culminant, et de la Haute-Loire et de l`Ardèche. C`est l`un des plus hauts sommets du Massif Central avec 1753m d`altitude, situé à l`Ouest du Cheylard.', '43', 2.5),
(45, 'Les Remparts de Guérande', 47.3273, -2.42717, 'Loire-Atlantique', 'Les Remparts de Guérande assuraient la protection de la cité médiévale. Malheureusement, on ne connaît la ville que pour son sel.', '44', 1.5),
(46, 'La Maison de Jeanne d`Arc', 47.9009, 1.90269, 'Loiret', 'Dans le centre d`Orléans se trouve la Maison de Jeanne d`Arc, sa résidence avant de devenir feu de joie des Anglais.', '45', 2),
(47, 'Le Gouffre de Padirac', 44.8582, 1.75046, 'Lot', 'Le Gouffre de Padirac est l`entrée monumentale d`une cavité naturelle de 103m de profondeur. Il se situe entre Brive-la-Gaillarde et Figeac, à hauteur de Sarlat-la-Canéda.', '46', 2),
(48, 'Le Château-musée Henri IV', 44.1353, 0.340415, 'Lot-et-Garonne', 'Le Château-musée Henri IV se trouve à Nérac, une commune au Sud-Ouest du Lot-et-Garonne. Il borde la Baïse, affluent de la Garonne.', '47', 3),
(49, 'Les Gorges du Tarn', 44.3644, 3.40996, 'Lozère', 'Les Gorges du Tarn sont une merveille géologique que la nature a creusée sur 53km. Elles se trouvent au Sud de Mende.', '48', 2),
(50, 'Le Château de Saumur', 47.257, -0.07238, 'Maine-et-Loire', ' Le Château de Saumur est classé monument historique en 1862, et est inscrit sur la liste du patrimoine mondial de l`UNESCO. Il est au Sud-Est d`Angers.', '49', 1.5),
(51, 'Le Mont-Saint-Michel', 48.636, -1.51143, 'Manche', 'Le Mont-Saint-Michel est l`un des lieux le plus touristique de France. Il est presque en Bretagne, mais reste normand !', '50', 1),
(52, 'La Cathédrale Notre-Dame de Reims', 49.2538, 4.0339, 'Marne', 'La Cathédrale Notre-Dame de Reims est majestueuse et imposante. Elle se situe au coeur de la ville.', '51', 1),
(2, 'La Cathédrale Saint-Gervais et Saint-Protais de Soissons', 49.3809, 3.32531, 'Aisne', 'Soissons se trouve entre Amiens et Reims. Elle est réputée pour son vase et sa bataille. La cathédrale se situe en son centre.', '02', 1.5),
(53, 'La Maison des Lumières Denis Diderot ', 47.8664, 5.33179, 'Haute-Marne', 'La Maison des Lumières Denis Diderot se trouve dans la ville de naissance de personnage historique, à Langres, entre Chaumont et Vesoul.', '52', 2.5),
(54, 'La Basilique Notre-Dame-des-Miracles de Mayenne', 48.3042, -0.617668, 'Mayenne', 'La Basilique Notre-Dame-des-Miracles de Mayenne se situe bien dans le département de la Mayenne, mais aussi dans la ville de Mayenne. Elle est proche d\'une rivière, la Mayenne ! ', '53', 2),
(55, 'La Place Stanislas', 48.6935, 6.18329, 'Meurthe-et-Moselle', 'La Place Stanislas a reçu le prix de la plus belle place d\'Europe. Elle est au centre de Nancy.', '54', 1.5),
(56, 'Le Fort de Vaux', 49.2004, 5.47038, 'Meuse', 'Le Fort de Vaux fut l\'un des endroits des plus stratégiques lors de la Première Guerre Mondiale. Il se situe au Nord-Est de Verdun, non loin du Mémorial. ', '55', 2),
(57, 'L\'Île aux Moines', 47.5889, -2.84998, 'Morbihan', 'L\'Île aux Moines est la plus grosse île du golfe du Morbihan. Elle offre point de vue génial sur celui-ci.', '56', 2),
(58, 'La Citadelle de Bitche', 49.0526, 7.43051, 'Moselle', 'La Citadelle de Bitche surplombe la ville, qui s\'est construite autour de sa colline. Bitche se trouve dans la queue de poêle de la Moselle.', '57', 1.5),
(59, 'Le Panorama du Calvaire', 47.0692, 3.93382, 'Nièvre', 'Le Panorama du Calvaire était un point de gué au coeur du Morvan, sur les hauteurs de Château-Chinon. ', '58', 3),
(60, 'Le Terril du Lavoir Rousseau', 50.4138, 3.51763, 'Nord', 'Le Terril du Lavoir Rousseau se trouve entre Valenciennes et la frontière belge. Il offre un panorama sur cette ville et sur sa banlieue.', '59', 2.5),
(61, 'Le Château de Chantilly', 49.1939, 2.48525, 'Oise', 'Le Château de Chantilly sublime cette ville pavée à l\'ambiance royale, à quelques pas au Nord de Paris.', '60', 1.5),
(62, 'Le Village de Camembert', 48.8935, 0.177598, 'Orne', 'Le Village de Camembert est l\'origine géographique du fromage le plus réputé du monde. Mais cette bourgade est minuscule. Elle se trouve au Sud-Est de Caen et au Nord-Est d\'Argentan.', '61', 3),
(63, 'L\'Entrée du Tunnel sous la Manche', 50.9229, 1.7803, 'Pas-de-Calais', 'Le Tunnel sous la Manche permet de rejoindre les terres anglaises depuis 1993. L\'Entrée se trouve sur la commune de Peuplingues, au Sud-Ouest de Calais.', '62', 1.5),
(64, 'Le Puy de Sancy', 45.5281, 2.81404, 'Puy-de-Dôme', 'Le Puy de Sancy représente le point culminant du Massif Central, à 1886m d\'altitude, au Sud-Ouest de Clermont-Ferrand.', '63', 2),
(65, 'L\'Île des Faisans', 43.3427, -1.76545, 'Pyrénées-Atlantiques', 'L\'Île des Faisans est un condominium franco-espagnol, c\'est-à-dire qu\'elle est en garde partagée entre les deux pays qui change chaque semestre. Les relations diplomatiques avec l\'Espagne se faisaient autrefois sur cet îlot, situé au Sud d\'Hendaye.', '64', 2.5),
(66, 'Sanctuaire Notre-Dame de Lourdes', 43.0976, -0.056614, 'Hautes-Pyrénées', 'La Basilique Notre-Dame de Lourdes est le lieu de pèlerinage le plus visité de France. Elle est sur la route de Saint-Jacques-de-Compostelle, dans l\'Ouest de la ville.', '65', 1.5),
(67, 'Pic du Canigou', 42.5192, 2.45594, 'Pyrénées-Orientales', 'Le Pic du Canigou est le sommet de la montagne symbolique des Pyrénées-Orientales. Elle culmine à 2785m d\'altitude et se trouve au Sud de Prades. ', '66', 2),
(68, 'La Place Kléber', 48.5834, 7.74576, 'Bas-Rhin', 'La Place Kléber se trouve au centre de Strasbourg. On y voit le mélange des maisons typiques alsaciennes et de l\'architecture moderne.', '67', 2),
(69, 'La Petite Venise', 48.0742, 7.3597, 'Haut-Rhin', 'La Petite Venise porte bien son nom : ce sont les maisons du Sud du centre de Colmar qui ont les pieds dans l\'eau ! Des maisons typiques alsaciennes bien sûr !', '68', 2.5),
(70, 'La Basilique Notre-Dame de Fourvière', 45.7623, 4.82253, 'Rhône', 'La Basilique Notre-Dame de Fourvière, malgré son tunnel horrible, domine Lyon de son altitude et de son caractère. Elle se trouve sur la rive droite de la Saône.', '69', 1),
(71, 'Le village de Presmes', 47.2782, 5.56572, 'Haute-Saône', 'Le village de Presmes situé sur les rives de l\'Ognon, entre Dijon et Besançon, charme grâce à son château et son prieuré.', '70', 3),
(72, 'L\'Abbaye de Cluny', 46.4344, 4.65888, 'Saône-et-Loire', 'L\'Abbaye de Cluny rayonne sur l\'Europe durant tout le Moyen-Âge avec près de 1400 dépendances. Cette ville est au Nord-Ouest de Mâcon.', '71', 2),
(73, 'Le Circuit des 24h du Mans', 47.956, 0.207945, 'Sarthe', 'Le Circuit des 24h du Mans est mythique. Chaque année, des dizaines de constructeurs essaient leurs véhicules sur celui-ci, situé au Sud du Mans.', '72', 1),
(74, 'Le Lac du Bourget', 45.7266, 5.86965, 'Savoie', 'Le Lac du Bourget concurrence le Lac d\'Annecy dans le Pays Savoyard. Il se trouve au Nord de Chambéry.', '73', 1.5),
(75, 'Le Mont Blanc', 45.8327, 6.86511, 'Haute-Savoie', 'Le Mont Blanc, du haut de ses 4808m, domine la Haute-Savoie, l\'Auvergne-Rhône-Alpes, la France, l\'Europe ! Il est au Sud de Chamonix mais est visible d\'une importante partie du Centre-Est français, avec de bonnes conditions. ', '74', 1),
(76, 'La Tour Eiffel', 48.8583, 2.2945, 'Paris', 'La Tour Eiffel, la Dame de Fer, le symbole architectural français reconnu partout dans le monde ! Elle se trouve au bout du Champ de Mars, dans l\'Ouest parisien. ', '75', 1),
(77, 'Les Falaises d\'Étretat', 49.7072, 0.193805, 'Seine-Maritime', 'Les Falaises d\'Étretat sont connues pour leur raideur et leurs arches impressionnantes. Se sont en fait des milliards de restes de crustacés qui forment la roche à cet endroit, au Nord du Havre.', '76', 1.5),
(78, 'Le Château de la Belle au Bois Dormant', 48.8732, 2.77607, 'Seine-et-Marne', 'La Belle au Bois Dormant loge ni dans un bois, ni dans un endroit calme mais en plein centre du Parc Disneyland, à l\'Est de Paris.', '77', 1.5),
(79, 'Le Château de Versailles', 48.8048, 2.12035, 'Yvelines', 'Le Château de Versailles, résidence des Rois de France depuis Louis XIV, conquiert encore et toujours l\'attention des touristes. Il est à l\'Ouest de la ville.', '78', 1),
(80, 'Le Donjon de Niort', 46.3253, -0.465075, 'Deux-Sèvres', 'Le Donjon de Niort pourrait faire rêver n\'importe quel enfant admiratif des Chevaliers. Il se place en plein centre-ville, au bord de la Sèvre.', '79', 1.5),
(81, 'Les Maisons Colorées de Mers-les-Bains', 50.0651, 1.38197, 'Somme', 'Les Maisons Colorées de Mers-les-Bains redonnent du vivant à la grisaille du Sud de la Baie de Somme.', '80', 2.5),
(82, 'Le Village de Cordes-sur-Ciel', 44.0636, 1.95097, 'Tarn', 'Le Village de Cordes-sur-Ciel est parmi les plus beaux de France. Basé sur un piton rocheux, il émerveille de son patrimoine religieux. Il se place au Nord-Ouest d\'Albi.', '81', 2.5),
(83, 'L\'Abbaye Saint-Pierre de Moissac', 44.1056, 1.08461, 'Tarn-et-Garonne', 'L’Abbaye Saint-Pierre avec son cloître et son tympan, inscrits patrimoine mondial de l’Humanité au titre des chemins de Saint-Jacques de Compostelle, sont les joyaux de Moissac, positionnée peu avant la confluence entre le Tarn et la Garonne.', '82', 2.5),
(84, 'Les Gorges du Verdon', 43.7628, 6.30601, 'Var', 'Les Gorges du Verdon impressionnent au vu de leur étroitesse et de leur profondeur. Malheureusement, le cours d\'eau subit de plus en plus fort les sécheresses provençales d\'été. Elles sont situées au Sud de Digne-les-Bains.', '83', 1.5),
(85, 'Le Colorado Provençal', 43.9129, 5.48718, 'Vaucluse', 'Le Colorado Provençal, de ses couleurs ocres, ajoute encore plus de couleurs dans le décor de cette magnifique région. Il est situé au Sud de Rustrel, qui est au Nord-Est d\'Apt.', '84', 2),
(86, 'L\'Île de Nourmoutier', 46.9712, -2.23887, 'Vendée', 'L\'Île est souvent surnommée l\'« île aux mimosas » pour sa douceur climatique permettant aux mimosas de pousser et d\'y fleurir en hiver. Elle se trouve tout à l\'Ouest du département.', '85', 1),
(87, 'Le Futuroscope', 46.666, 0.36408, 'Vienne', 'Le Futuroscope est un parc de loisirs à thème technologique, scientifique, d\'anticipation et ludique, dont les attractions mélangent approches sensorielles et projections d\'images. Il est situé au Nord de Poitiers.', '86', 2),
(88, 'Le Village Martyr d\'Oradour-sur-Glane', 45.9311, 1.03245, 'Haute-Vienne', 'Le 10 Juin 1944, la population d’Oradour-sur-Glane, au Nord-Ouest de Limoges, est massacrée par une troupe de Waffen SS. Le Centre de la Mémoire explique aux visiteurs ce terrible fait historique.', '87', 2),
(89, 'Le Ballon d\'Alsace', 47.8233, 6.84618, 'Vosges', 'Le ballon d\'Alsace, qui culmine à 1 247 mètres d\'altitude, offre un large panorama, la Forêt-Noire à l\'Est, le Jura, la trouée de Belfort et, par temps clair, le mont Blanc au Sud, et les crêtes des Vosges au Nord. Il est au tripoint des Vosges, du Territoire de Belfort et du Haut-Rhin.', '88', 1.5),
(90, 'L\'Abbaye de Vézelay', 47.4664, 3.74859, 'Yonne', 'L\'Abbaye de Vézelay, bien que petit village, est le point de départ de l\'une des principales voies de pèlerinage de Saint-Jacques-de-Compostelle, la Via Lemovicensis.', '89', 2),
(91, 'Le Lion de Bartholdi', 47.6366, 6.86452, 'Territoire de Belfort', 'Œuvre du sculpteur alsacien Auguste Bartholdi, le Lion commémore la résistance de la ville de Belfort assiégée par les Prussiens durant la guerre franco-allemande de 1870.', '90', 2),
(92, 'Le Château de Dourdan', 48.5298, 2.01116, 'Essonne ', 'Le Château de Dourdan est un ancien château fort. Dourdan se trouve dans la région naturelle du Hurepoix, à l\'Ouest du département. ', '91', 2),
(93, 'La Tour aux Figures', 48.8285, 2.2585, 'Hauts-de-Seine', 'Haute de 24 mètres, la Tour aux Figures a été réalisée d’après la maquette conçue en 1967 par Jean Dubuffet. Son ossature en béton armé est recouverte d\'une coque constituée de 90 panneaux moulés en résine époxy. Elle se trouve sur l\'Île Saint-Germain, à Issy-les-Moulineaux.', '92', 2),
(94, 'Le Stade de France', 48.9244, 2.36013, 'Seine-Saint-Denis', 'Le Stade de France accueille chaque année des milliers de sportifs et des millions de spectateurs. Il se trouve au Sud de Saint-Denis.', '93', 1),
(95, 'Le Château de Vincennes', 48.8426, 2.43632, 'Val-de-Marne', 'Le Château de Vincennes est le plus grand château fort royal subsistant en France et, du fait de la hauteur de son donjon une des plus hautes forteresses de plaine d\'Europe. Il se trouve juste à l\'Est de Paris.', '94', 1),
(96, 'La Tombe de Vincent Van Gogh', 49.0753, 2.17896, 'Val-d\'Oise', 'La Tombe de Vincent Van Gogh recueille la dépouille d\'un des peintres les plus reconnus du monde. Elle se trouve dans le cimetière d\'Auvers-sur-Oise, entre Pontoise et l\'Isle-Adam.', '95', 3);

-- --------------------------------------------------------

--
-- Structure de la table `objets`
--

DROP TABLE IF EXISTS `objets`;
CREATE TABLE IF NOT EXISTS `objets` (
  `o_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `o_nom` varchar(20) COLLATE utf8_bin NOT NULL,
  `o_png` varchar(20) COLLATE utf8_bin NOT NULL,
  `o_longueur` int(3) NOT NULL,
  `o_hauteur` int(3) NOT NULL,
  UNIQUE KEY `id` (`o_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `objets`
--

INSERT INTO `objets` (`o_id`, `o_nom`, `o_png`, `o_longueur`, `o_hauteur`) VALUES
(1, 'Parchemin', 'parchemin.svg', 70, 70),
(2, 'Clé', 'cle.svg', 80, 80),
(3, 'Coffre à clé', 'coffre2.svg', 150, 150),
(4, 'Coffre à code', 'coffre_fort.svg', 200, 200);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
